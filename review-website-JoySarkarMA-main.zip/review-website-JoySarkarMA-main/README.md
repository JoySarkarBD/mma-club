# MMA CLUB

This is the live site link(https://mma-club.netlify.app/).

<ul>
  <li>This site is made for educational purpose.</li>
  <li>I build this site with react js, react font awesome, and react bootstrap.</li>
  <li>By this site I am trying to catch attention of those popole who doesn't really care about their defense.</li>
</ul>

